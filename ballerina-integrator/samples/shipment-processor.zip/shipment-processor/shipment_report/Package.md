Use the below command to generate Ballerina bindings for Java dependency

`bal bindgen -cp org.Utilities.Util org.Utilities.Util, java.util.Map`